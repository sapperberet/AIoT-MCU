import cv2
from ultralytics import YOLO
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt

# تحميل النموذج المدرب
model = YOLO("fire_model.pt")

# فتح الفيديو (غيّر المسار حسب مكان الفيديو عندك)
video_path = "fire.mp4"
cap = cv2.VideoCapture(video_path)

# ground truth: الفيديو كله fire → label = 0
y_true = []
y_pred = []

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame)
    for r in results:
        for box in r.boxes:
            cls_id = int(box.cls[0])   # التوقع من النموذج
            y_true.append(0)           # الحقيقة: كله fire
            y_pred.append(cls_id)

cap.release()

# حساب المقاييس (كلاس واحد فقط)
accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred, labels=[0], average='macro', zero_division=0)
recall = recall_score(y_true, y_pred, labels=[0], average='macro', zero_division=0)
f1 = f1_score(y_true, y_pred, labels=[0], average='macro', zero_division=0)

print("\n=== Evaluation Results ===")
print(f"Accuracy: {accuracy:.2f}")
print(f"Precision (fire): {precision:.2f}")
print(f"Recall (fire): {recall:.2f}")
print(f"F1 Score (fire): {f1:.2f}")

# رسم الجراف
metrics = [accuracy, precision, recall, f1]
names = ["Accuracy", "Precision", "Recall", "F1 Score"]

plt.bar(names, metrics, color=['blue','green','orange','red'])
plt.ylim(0,1)
plt.title("Fire Detection Performance (Single Class)")
plt.ylabel("Score")
for i, v in enumerate(metrics):
    plt.text(i, v + 0.02, f"{v:.2f}", ha='center', fontsize=10)
plt.show()
