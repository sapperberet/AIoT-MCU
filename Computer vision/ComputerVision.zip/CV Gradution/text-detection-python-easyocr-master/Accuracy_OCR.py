import os
import cv2
import easyocr
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt

# إنشاء كائن EasyOCR
reader = easyocr.Reader(['en'], gpu=False)

# فولدر الصور
data_dir = "data"

# هنا لازم تحدد Ground Truth لكل صورة
# مثال: {"اسم الصورة": "النص الحقيقي"}
ground_truth = {
    "test1.webp": "amazon"
    
}

y_true = []
y_pred = []

# المرور على الصور في الفولدر
for img_name, true_text in ground_truth.items():
    img_path = os.path.join(data_dir, img_name)
    img = cv2.imread(img_path)

    if img is None:
        print(f"⚠️ الصورة {img_name} مش موجودة")
        continue

    results = reader.readtext(img)

    if results:
        # ناخد أعلى نتيجة (أعلى score)
        _, detected_text, score = max(results, key=lambda x: x[2])
        y_true.append(true_text.lower())
        y_pred.append(detected_text.lower())
        print(f"Image: {img_name} | GT: {true_text} | OCR: {detected_text} | Score: {score:.2f}")
    else:
        y_true.append(true_text.lower())
        y_pred.append("")

# حساب المقاييس
accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred, average='micro', zero_division=0)
recall = recall_score(y_true, y_pred, average='micro', zero_division=0)
f1 = f1_score(y_true, y_pred, average='micro', zero_division=0)

print("\n=== OCR Evaluation Results ===")
print(f"Accuracy: {accuracy:.2f}")
print(f"Precision: {precision:.2f}")
print(f"Recall: {recall:.2f}")
print(f"F1 Score: {f1:.2f}")

# رسم الجراف
metrics = [accuracy, precision, recall, f1]
names = ["Accuracy", "Precision", "Recall", "F1 Score"]

plt.bar(names, metrics, color=['blue','green','orange','red'])
plt.ylim(0,1)
plt.title("OCR Performance (EasyOCR)")
plt.ylabel("Score")
for i, v in enumerate(metrics):
    plt.text(i, v + 0.02, f"{v:.2f}", ha='center', fontsize=10)
plt.show()
