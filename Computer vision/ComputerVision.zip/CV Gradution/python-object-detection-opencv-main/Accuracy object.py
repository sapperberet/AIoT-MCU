import cv2
import os
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# ===== إعداد النموذج =====
classFile = 'coco.names'
with open(classFile, 'rt') as f:
    classNames = f.read().rstrip('\n').split('\n')

configPath = 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'
weightPath = 'frozen_inference_graph.pb'

net = cv2.dnn_DetectionModel(weightPath, configPath)
net.setInputSize(320, 320)
net.setInputScale(1.0 / 127.5)
net.setInputMean((127.5, 127.5, 127.5))
net.setInputSwapRB(True)

# ===== فولدر الصور للاختبار =====
test_path = 'Test'   # ضع هنا فولدر الصور اللي عايز تختبرها
test_files = os.listdir(test_path)

y_true = []
y_pred = []

for file in test_files:
    img = cv2.imread(os.path.join(test_path, file))
    classIds, confs, bbox = net.detect(img, confThreshold=0.5)

    # استخراج الـ true label من اسم الملف (مثلاً person_1.jpg → person)
    true_label = os.path.splitext(file)[0].split("_")[0].lower()

    if len(classIds) != 0:
        # ناخد أول كائن متعرف عليه
        classId = classIds.flatten()[0]
        predicted_label = classNames[classId - 1].lower()
    else:
        predicted_label = "unknown"

    y_true.append(true_label)
    y_pred.append(predicted_label)

    print(f"File: {file}, True: {true_label}, Predicted: {predicted_label}")

# ===== حساب المقاييس =====
print("\n=== Evaluation Results ===")
print("Accuracy:", accuracy_score(y_true, y_pred))
print("Precision:", precision_score(y_true, y_pred, average='macro', zero_division=1))
print("Recall:", recall_score(y_true, y_pred, average='macro', zero_division=1))
print("F1 Score:", f1_score(y_true, y_pred, average='macro', zero_division=1))

# ===== رسم Confusion Matrix =====
cm = confusion_matrix(y_true, y_pred, labels=list(set(y_true)))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=list(set(y_true)),
            yticklabels=list(set(y_true)))
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Confusion Matrix")
plt.show()
