import cv2
import easyocr


reader = easyocr.Reader(['en'], gpu=False)

cap = cv2.VideoCapture(0)
threshold = 0.1  

while True:
    ret, frame = cap.read()
    if not ret:
        break

    
    small_frame = cv2.resize(frame, (640, 480))

    
    results = reader.readtext(small_frame)

    for bbox, text, score in results:
        if score > threshold:
            
            (x1, y1), (x2, y2), (x3, y3), (x4, y4) = bbox

            
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x3), int(y3)), (0, 255, 0), 2)

            
            cv2.putText(frame, text, (int(x1), int(y1) - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

            print(f"Detected: {text} (score={score:.2f})")

    cv2.imshow("Text Detection (EasyOCR)", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
