# text-detection-python-easyocr

In this video I show you how to make an optical character recognition algorithm using Python, OpenCV and EasyOCR in 15 minutes!

[![Watch the video](https://img.youtube.com/vi/n-8oCPjpEvM/0.jpg)](https://www.youtube.com/watch?v=n-8oCPjpEvM)
