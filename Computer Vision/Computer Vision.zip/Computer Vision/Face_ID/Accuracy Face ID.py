import cv2
import numpy as np
import face_recognition
import os
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt


train_path = 'persons'
images = []
classNames = []
personsList = os.listdir(train_path)

for cl in personsList:
    curPerson = cv2.imread(f'{train_path}/{cl}')
    images.append(curPerson)
    classNames.append(os.path.splitext(cl)[0])

def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encodes = face_recognition.face_encodings(img)
        if encodes:
            encodeList.append(encodes[0])
    return encodeList

encodeListKnown = findEncodings(images)
print("Encoding Complete.")


test_path = 'Test'   
test_files = os.listdir(test_path)

y_true = []
y_pred = []

for file in test_files:
    img = cv2.imread(f'{test_path}/{file}')
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    encodes = face_recognition.face_encodings(img_rgb)

    true_label = os.path.splitext(file)[0].split("_")[0]  
    

    if encodes:
        encode = encodes[0]
        matches = face_recognition.compare_faces(encodeListKnown, encode)
        faceDis = face_recognition.face_distance(encodeListKnown, encode)
        matchIndex = np.argmin(faceDis)

        predicted_label = classNames[matchIndex] if matches[matchIndex] else "Unknown"
    else:
        predicted_label = "Unknown"

    y_true.append(true_label.upper())
    y_pred.append(predicted_label.upper())


print("Accuracy:", accuracy_score(y_true, y_pred))
print("Precision:", precision_score(y_true, y_pred, average='macro'))
print("Recall:", recall_score(y_true, y_pred, average='macro'))
print("F1 Score:", f1_score(y_true, y_pred, average='macro'))


cm = confusion_matrix(y_true, y_pred, labels=list(set(y_true)))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=list(set(y_true)),
            yticklabels=list(set(y_true)))
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Confusion Matrix")
plt.show()
