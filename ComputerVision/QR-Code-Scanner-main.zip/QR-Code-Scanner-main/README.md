# QR-Code-Scanner

In this project we are building a QR Code or Bar Code Scanner using OpenCV and Python. So at the end you will have your own QR/Bar Code Scanner.
Library which we are going to use is Pyzbar, which will help us to decode our QR/Bar Code.

So in this program we are mainly focusing on Video which means we will scan our code through WebCam

If you have any doubts in the program you can reach out to me
