Open cv fire detection system. watch the video until
the end and comment out if you need any assistance.